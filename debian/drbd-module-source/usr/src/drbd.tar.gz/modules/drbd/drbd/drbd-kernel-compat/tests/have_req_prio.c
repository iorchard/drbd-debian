/* { "version": "v3.2", "commit": "65299a3b788bd274bed92f9fa3232082c9f3ea70", "author": "Christoph Hellwig <hch@infradead.org>", "date": "Tue Aug 23 14:50:29 2011 +0200" } */
#include <linux/blk_types.h>

int dummy = REQ_PRIO;
